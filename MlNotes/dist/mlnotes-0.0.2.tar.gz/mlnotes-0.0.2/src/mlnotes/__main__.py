# # mlnotes/__main__.py

# from .mlnotes import add_notes, show_notes

# if __name__ == "__main__":
#     # Your code to execute when running the package as a script
#     add_notes(2, "Sample note")


from .mlnotes import add_notes

if __name__ == '__main__':
    add_notes(1, "Sample note")