# *** Save information of your ml projects ***
### ---- Save eda information and access any time
### ---- Save ml project information and access any time
### ---- It saves your project information in ai_info.json file on your own computer
### ---- No one will able to see your data execpt you
### ---- Your project data is saved on your pc not in any database

# *** All commandas ***

## 1. mlnotes.add_notes(note_id, your note goes here)
## 2. mlnotes.show_notes(note_id)