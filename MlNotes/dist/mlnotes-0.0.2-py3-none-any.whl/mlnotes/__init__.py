# mlnotes/__init__.py

from .mlnotes import add_notes, show_notes
